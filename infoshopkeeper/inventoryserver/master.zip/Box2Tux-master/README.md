Box2Tux
=======

this is a webdav(gvfs-mount) based box.com client
=======
This is a box.com client for GNOME, Elementary OS(Pantheon), Cinnamon, Unity and other gtk+3 based desktop environment.
=======
The old version are deleted for security problem and because are very slow.
=======
For Kde/Lxqt/Xfce users, use the add network resource tool in your file manager or install gvfs.




